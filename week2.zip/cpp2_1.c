#include <stdio.h>

int main(void)
{
    int height;

    printf("Please enter the position of the ball\n");
    scanf("%d", &height);

    if(height>=50&&height<=60){
        printf("win");
    }
    else{
        printf("lose");
    }

    return 0;
}