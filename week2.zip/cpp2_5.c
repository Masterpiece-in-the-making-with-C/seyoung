#include <stdio.h>

int main(void)
{
    int cha = 0;
    int count = 0;

    scanf("%d", &cha);
    if (cha > 100000 || cha < 1)
    {
        printf("Please enter a number within the valid range");
    }

    while (cha > 0)
    {
        if (cha % 5 == 0)
        {
            count += cha / 5;
            break;
        }
        else
        {
            cha -= 2;
            count += 1;
        }
    }
    if (cha < 0)
    {
        printf("-1");
    }
    else
    {
        printf("%d", count);
    }

    return 0;
}